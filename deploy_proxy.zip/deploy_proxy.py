
import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

BASE_URL = "https://apigee.googleapis.com/v1"


def get_token():
    """Read OAuth access token from environment variable."""
    token = os.environ.get("APIGEE_ACCESS_TOKEN")

    if not token:
        raise RuntimeError(
            "Missing APIGEE_ACCESS_TOKEN environment variable"
        )

    return token.strip()


def api_get(path, token):
    """Execute GET request to Apigee Management API."""
    request = urllib.request.Request(
        BASE_URL + path,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json"
        },
        method="GET"
    )

    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.load(response)

    except urllib.error.HTTPError as error:
        details = error.read().decode()
        raise RuntimeError(
            f"HTTP {error.code}: {details}"
        ) from error


def deploy_proxy(org, proxy, environment, revision, token):
    """Deploy an existing API Proxy revision."""
    path = (
        f"/organizations/{urllib.parse.quote(org, safe='')}"
        f"/environments/{urllib.parse.quote(environment, safe='')}"
        f"/apis/{urllib.parse.quote(proxy, safe='')}"
        f"/revisions/{revision}/deployments"
    )

    request = urllib.request.Request(
        BASE_URL + path,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        data=b"",
        method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            body = response.read().decode("utf-8")
            result = json.loads(body) if body else {}

            print("Deployment API response:")
            print(json.dumps(result, indent=2))

            return result

    except urllib.error.HTTPError as error:
        details = error.read().decode()
        raise RuntimeError(
            f"Deployment failed: HTTP {error.code}: {details}"
        ) from error


def main():
    parser = argparse.ArgumentParser(
        description="Deploy existing Apigee API Proxy revision"
    )

    parser.add_argument(
        "proxy",
        help="Name of existing API Proxy"
    )

    parser.add_argument(
        "environment",
        help="Target Apigee environment"
    )

    parser.add_argument(
        "--revision",
        type=int,
        help="Revision number (default: latest)"
    )

    args = parser.parse_args()

    if args.revision is not None and args.revision < 1:
        parser.error("Revision must be a positive integer")

    org = os.environ.get("APIGEE_ORG")

    if not org:
        raise RuntimeError(
            "Missing APIGEE_ORG environment variable"
        )

    token = get_token()

    # Verify environment exists
    environment = api_get(
        f"/organizations/{urllib.parse.quote(org, safe='')}"
        f"/environments/{urllib.parse.quote(args.environment, safe='')}",
        token
    )

    print(f"Environment: {environment['name']}")

    # Retrieve available proxy revisions
    revisions = api_get(
        f"/organizations/{urllib.parse.quote(org, safe='')}"
        f"/apis/{urllib.parse.quote(args.proxy, safe='')}/revisions",
        token
    )

    available = [int(rev) for rev in revisions]

    if not available:
        raise RuntimeError("No revisions found for API Proxy")

    # Select latest or requested revision
    revision = (
        args.revision
        if args.revision is not None
        else max(available)
    )

    if revision not in available:
        raise RuntimeError(
            f"Revision {revision} does not exist. "
            f"Available revisions: {available}"
        )

    print(f"API Proxy: {args.proxy}")
    print(f"Available revisions: {available}")
    print(f"Selected revision: {revision}")
    print("Validation successful. Starting deployment...")

    # Deploy selected revision
    deploy_proxy(
        org,
        args.proxy,
        args.environment,
        revision,
        token
    )

    print("Deployment request accepted by Apigee API.")
    print("Runtime readiness has not been verified.")


if __name__ == "__main__":
    try:
        main()
    except (
        RuntimeError,
        urllib.error.URLError,
        OSError,
        ValueError,
        KeyError,
        json.JSONDecodeError
    ) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
